import cv2
import numpy as np
import yaml

class Camera:
    def __init__(self, camera_id, resolution, calibration_filename, crops = None):
        self.camera_id = camera_id
        self.width = resolution[0]
        self.heigth = resolution[1]
        
        self.crops = crops

        self.cap=cv2.VideoCapture(self.camera_id)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.heigth)

        self.calibration = Calibration(calibration_filename) 
        self.calibration.load()

    def capture(self):
        ret, frame = self.cap.read()
    
        if not isinstance(self.crops,type(None)) and ret:
            img = [frame[crop[0]:crop[1], crop[2]:crop[3]] for crop in self.crops]
        else:
            img = frame

        return ret, img

    def is_valid_crop(self, crops):
        if not isinstance(crops,list):
            return False
        if isinstance(crops,list):
            if len(crops)==0:
                return False
            if not isinstance(crops[0],list):
                crops = [crops]
            for crop in crops:
                if len(crop) != 4:
                    return False
                for i in crop:
                    if not(isinstance(i,int)):
                        return False
                if crop[0]<0 or crop[1]>self.heigth or crop[2]<0 or crop[3]>self.width:
                    return False       
        return True
    
    def close(self):
        self.cap.release()

    def undistort(self, image, side):
        if side.lower() == "left":
            self.calibration.newcamera_matrix_L, roi = cv2.getOptimalNewCameraMatrix(self.calibration.camera_matrix_L, self.calibration.dist_L,
                                                                  (self.calibration.height_L, self.calibration.width_L), 0, 
                                                                  (self.calibration.height_L, self.calibration.width_L))
            uimg = cv2.undistort(image, self.calibration.camera_matrix_L, self.calibration.dist_L, None, self.calibration.newcamera_matrix_L)
        elif side.lower() == "right":
            self.calibration.newcamera_matrix_R, roi = cv2.getOptimalNewCameraMatrix(self.calibration.camera_matrix_R, self.calibration.dist_R,
                                                                  (self.calibration.height_R, self.calibration.width_R), 0, 
                                                                  (self.calibration.height_R, self.calibration.width_R))
            uimg = cv2.undistort(image, self.calibration.camera_matrix_R, self.calibration.dist_R, None, self.calibration.newcamera_matrix_R)
        return uimg,roi



class Calibration:
    def __init__(self, calibration_filename):
        self.n = 0
        self.calibration_filename = calibration_filename
        self.camera_matrix_L = None
        self.camera_matrix_R = None
        self.newcamera_matrix_L = None
        self.newcamera_matrix_R = None
        self.dist_L = None
        self.dist_R = None
        self.height_L = None
        self.width_L = None
        self.height_R = None
        self.width_R = None
        self.rectification_transform_L = None
        self.rectification_transform_R = None
        self.projection_matrix_L = None
        self.projection_matrix_R = None
        self.camera_matrix = None
        self.dist = None
        self.height = None
        self.width = None

    def load(self):
        with open(self.calibration_filename) as file:
            params = yaml.safe_load(file)
        try:
            if "LEFT.P" in list(params.keys()):
                self.camera_matrix_L = np.asarray(params["LEFT.K"]["data"]).reshape((params["LEFT.K"]["rows"], params["LEFT.K"]["cols"]))
                self.camera_matrix_R = np.asarray(params["RIGHT.K"]["data"]).reshape((params["RIGHT.K"]["rows"], params["RIGHT.K"]["cols"]))
                self.dist_L = np.asarray(params["LEFT.D"]["data"]).reshape((params["LEFT.D"]["rows"], params["LEFT.D"]["cols"]))
                self.dist_R = np.asarray(params["RIGHT.D"]["data"]).reshape((params["RIGHT.D"]["rows"], params["RIGHT.D"]["cols"]))
                self.height_L = int(params["LEFT.height"])
                self.width_L = int(params["LEFT.width"])
                self.height_R = int(params["RIGHT.height"])
                self.width_R = int(params["RIGHT.width"])
                self.rectification_transform_L = np.asarray(params["LEFT.R"]["data"]).reshape((params["LEFT.R"]["rows"], params["LEFT.R"]["cols"]))
                self.rectification_transform_R = np.asarray(params["RIGHT.R"]["data"]).reshape((params["RIGHT.R"]["rows"], params["RIGHT.R"]["cols"]))
                self.projection_matrix_L = np.asarray(params["LEFT.P"]["data"]).reshape((params["LEFT.P"]["rows"], params["LEFT.P"]["cols"]))
                self.projection_matrix_R = np.asarray(params["RIGHT.P"]["data"]).reshape((params["RIGHT.P"]["rows"], params["RIGHT.P"]["cols"]))
                self.n = 2
            else:
                self.camera_matrix = np.asarray([[params["Camera.fx"],0.0,params["Camera.cx"]],[0.0, params["Camera.fx"],params["Camera.cx"]],[0.0,0.0,1.0]])
                if "Camera.k3" in list(params.keys()):
                    self.dist = np.asarray([params["Camera.k1"],params["Camera.k2"],params["Camera.p1"],params["Camera.p2"],params["Camera.k3"]])
                else:
                    self.dist = np.asarray([params["Camera.k1"],params["Camera.k2"],params["Camera.p1"],params["Camera.p2"]])
                self.height = int(params["Camera.height"])
                self.width = int(params["Camera.width"])
                self.n = 1
            return True
        except:
            return False
