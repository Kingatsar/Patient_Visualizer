from rospkg import RosPack
import rospy
from sensor_msgs.msg import *
from std_msgs.msg import *
import cv2
from cv_bridge import CvBridge
import json
import numpy as np
import yaml

class ImagePublisher:
    def __init__(self, topic, id = 'imagepublisher_node', rate = 10, encoding = 'passthrough'):
        
        self.topic = topic
        self.encoding = encoding
        
        rospy.init_node(id, anonymous=True)
        self.pub = rospy.Publisher(topic, Image, queue_size=1) 
        rospy.loginfo(id + " Started")
        self.rate = rospy.Rate(rate)
        self.bridge = CvBridge()

    def publish(self, image):
        self.pub.publish(self.bridge.cv2_to_imgmsg(image, encoding=self.encoding))

    def sleep(self):
        self.rate.sleep()

    def change_rate(self,rate):
        self.rate = rospy.Rate(rate)

class StringSubscriber:
    def __init__(self, topic, id = 'subscriber_node', callback = None):
        if callback == None:
            self.callback = self.print_message
        else:
            self.callback = callback

        self.sub = rospy.Subscriber(topic, String, callback=self.callback)
        rospy.loginfo(id + " Started")
    
    def print_message(self, data):
        print(data.data)
    
    