import cv2
import cv2.aruco as aruco

ARUCO_DICT = {
    "DICT_4X4_50": aruco.DICT_4X4_50,
    "DICT_4X4_100": aruco.DICT_4X4_100,
    "DICT_4X4_250": aruco.DICT_4X4_250,
    "DICT_4X4_1000": aruco.DICT_4X4_1000,
    "DICT_5X5_50": aruco.DICT_5X5_50,
    "DICT_5X5_100": aruco.DICT_5X5_100,
    "DICT_5X5_250": aruco.DICT_5X5_250,
    "DICT_5X5_1000": aruco.DICT_5X5_1000,
    "DICT_6X6_50": aruco.DICT_6X6_50,
    "DICT_6X6_100": aruco.DICT_6X6_100,
    "DICT_6X6_250": aruco.DICT_6X6_250,
    "DICT_6X6_1000": aruco.DICT_6X6_1000,
    "DICT_7X7_50": aruco.DICT_7X7_50,
    "DICT_7X7_100": aruco.DICT_7X7_100,
    "DICT_7X7_250": aruco.DICT_7X7_250,
    "DICT_7X7_1000": aruco.DICT_7X7_1000,
    "DICT_ARUCO_ORIGINAL": aruco.DICT_ARUCO_ORIGINAL,
}


class ArucoPatternDetector:
    """Aruco Pattern Detector"""

    def __init__(self, aruco_dictionary):
        aruco_dictionary = ARUCO_DICT[aruco_dictionary]
        self.aruco_dict = aruco.Dictionary_get(aruco_dictionary)
        self.parameters = aruco.DetectorParameters_create()

    def find_aruco_marker(self, image):
        # Convert RGB to Grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Lists of detected markers and the corners beloning to each marker
        corners, ids, rejected_img_points = aruco.detectMarkers(
            gray, self.aruco_dict, parameters=self.parameters
        )
        # Draw a square around the markers
        if not (isinstance(corners, type(None))):
            aruco.drawDetectedMarkers(image, corners)
        return image, corners, ids, rejected_img_points