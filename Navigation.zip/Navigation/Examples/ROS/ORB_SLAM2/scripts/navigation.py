import json

from camera import Camera
from ros_messenger import *
from aruco_detection import ArucoPatternDetector
import cv2.aruco as aruco

import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showinfo
import threading

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib as mpl
mpl.use('TkAgg')

#from rendering import render_arrow
import math



class Navigator:
    def __init__(self, params):
        self.params = params
        crops = [params["camera"]["left_crop"],params["camera"]["right_crop"]]
        self.camera = Camera(params["camera"]["id"],params["camera"]["resolution"],params["camera"]["calibration_filename"],crops)
        self.Twc = None
        self.Twa = dict()
        self.Tad = None
        self.aruco_positions = dict()
        self.left_image_topic = params["topics"]["left_image"]
        self.right_image_topic = params["topics"]["right_image"]
        self.camera_tracking_topic = params["topics"]["camera_tracking"]
        self.aruco_detector = ArucoPatternDetector(params["aruco"]["vocabulary"])
        self.aruco_size = params["aruco"]["size"]
        self.curr_position_wc = None
        self.points = None

        #self.gui = threading.Thread(target = self.run_selector)
        #self.gui.start() 
        self.give_indications = False
        self.destination = None
        self.current_arucos = []

        self.aruco_ref = np.asarray(
            [
                [-self.aruco_size / 2, 0, 0],
                [self.aruco_size / 2, 0, 0],
                [self.aruco_size / 2, self.aruco_size / 2, 0],
                [-self.aruco_size / 2, self.aruco_size / 2, 0],
            ])

        plt.ion()
        self.fig = plt.figure()
        self.ax = self.fig.add_subplot(111, projection='3d')

        self.Tac = dict()
     
        


        self.cb = None

        #self.gui = threading.Thread(target = self.run_selector)
        #self.gui.start() 

        #self.points_plot = threading.Thread(target = self.plot_3D_positions)
        #self.points_plot.start() 
            
    def on_Twc_received(self,data):
        data = json.loads(data.data)
        if len(data) == 16:
            data = np.asarray(data)
            self.Twc = np.linalg.inv(data.reshape((4,4)))
        else:
            self.Twc = None
        
    
    
    def start(self):
        self.left_image_pub = ImagePublisher(self.left_image_topic)
        self.right_image_pub = ImagePublisher(self.right_image_topic)
        self.camera_tracking_sub = StringSubscriber(self.camera_tracking_topic, callback=self.on_Twc_received)

        ret = True
        while ret:
            ret,img = self.camera.capture()
            if ret:
                left = img[0]
                right = img[1]
                
                
                self.left_image_pub.publish(left)
                self.right_image_pub.publish(right)

                self.track_aruco(left, right)
                self.update_Tac()
                self.check_nav_status()

                self.left_image_pub.sleep()
            else:
                break

            k=cv2.waitKey(1)
            if k==ord("q"):
                break
            self.plot_3D_positions()

    def stop(self):            
        self.camera.close()
        self.root.quit()
        self.root.destroy()


    def update_Tac(self):
        if type(self.Twc) != type(None) and len(self.Twa)>0:
            for k in list(self.Twa.keys()):
                self.Tac[k] = np.linalg.inv(self.Twc) @ self.Twa[k]

    
    def track_aruco(self, left, right):
        left,_ = self.camera.undistort(left, "left")
        right,_ = self.camera.undistort(right, "right")
                
        drawn_left, corners_left, ids_left, _ = self.aruco_detector.find_aruco_marker(left)
        drawn_right, corners_right, ids_right, _ = self.aruco_detector.find_aruco_marker(right)
        
        """
        destination = "5"

        if type(self.Twc)!=type(None) and (destination in list(self.Tac.keys())):
            
            camera_matrix = self.camera.calibration.camera_matrix_L
            
            scale=0.1

            Tcw = np.linalg.inv(self.Twc)

            transform = self.Twa[destination].copy()
            
            #drawn_left, self.points = render_arrow(drawn_left,camera_matrix, transform, Tcw, l1 = 0.2*scale, l2 = 0.5*scale, h1 = 1.5*scale, h2 = 1*scale, d = 0 *scale)
        """
        cv2.imshow("left",drawn_left)

        
        
        if not isinstance(ids_left, type(None)) and not isinstance(ids_right, type(None)):

            self.current_arucos_left = [id[0] for id in ids_left]
            self.current_arucos_right = [id[0] for id in ids_right]

            if type(self.Twc)!= type(None):
                current_Twc = self.Twc.copy()
            else:
                current_Twc = None

            common = [value for value in self.current_arucos_left if value in self.current_arucos_right]
            if len(common)>0:

                for id in common:
                    tmp_aruco_left = corners_left[self.current_arucos_left.index(id)]
                    tmp_aruco_right = corners_right[self.current_arucos_right.index(id)]
                    homogeneous_4d_coords = cv2.triangulatePoints(self.camera.calibration.projection_matrix_L, self.camera.calibration.projection_matrix_R,
                                                                tmp_aruco_left, tmp_aruco_right)
                    threeD_coords = cv2.convertPointsFromHomogeneous(homogeneous_4d_coords.transpose())
                    output_points = [(point[0][0], point[0][1], point[0][2]) for point in threeD_coords]
                    output_points = np.asarray(output_points)
                    Tca, _, _ = self.rigid_transform_3D(output_points.T,self.aruco_ref.T)
                    

                    if type(current_Twc) != type(None):                   
                    
                        self.Twa[str(id)] = current_Twc @ np.linalg.inv(Tca.copy())

                        output_points = output_points.T
                        output_points = np.concatenate((output_points, np.ones((1,4))), axis = 0)
                        self.aruco_positions[str(id)] = current_Twc @ output_points
                        self.aruco_positions[str(id)] = self.aruco_positions[str(id)][:3,:]

                        origin = np.asarray([0,0,0,1])[:,np.newaxis] 
                        tmp = self.Twa[str(id)] @ origin


                        #pos = self.aruco_positions[str(id)]
                        #aruco_center = np.asarray([np.mean(pos[0][:]), np.mean(pos[1][:]), np.mean(pos[2][:])])


                self.current_arucos = common
            else:
                self.current_arucos = []
                
        else:
            self.current_arucos=[]
               
        if type(self.cb)!=type(None):
            self.cb['values'] = list(self.Twa.keys())
        
        
    def run_selector(self):
        self.root = tk.Tk()

        # config the root window
        self.root.geometry('300x200')
        self.root.resizable(False, False)
        self.root.title('Combobox Widget')

        # label
        self.label = ttk.Label(text="Select your destination:")
        self.label.pack(fill=tk.X, padx=5, pady=5)

        # create a combobox
        self.selected = tk.StringVar()
        self.cb = ttk.Combobox(self.root, textvariable=self.selected)

        # get first 3 letters of every month name
        self.cb['values'] = list(self.Twa.keys())

        # prevent typing a value
        self.cb['state'] = 'readonly'

        # place the widget
        self.cb.pack(fill=tk.X, padx=5, pady=5)

        self.cb.bind('<<ComboboxSelected>>', self.aruco_changed)

        self.root.mainloop()

    # bind the selected value changes
    def aruco_changed(self,event):
        showinfo(title='Result', message=f'You selected {self.selected.get()}!')
        self.give_indications = True
        self.destination = self.selected.get()
        self.update_Tad()
        

    def update_Tad(self):
        if self.give_indications:
            if type(self.Twc) != type(None):
                self.Tad =  np.linalg.inv(self.Twc.copy()) @ self.Twa[self.selected.get()].copy()
            else:
                self.Tad = None
            

    def check_nav_status(self):
        if self.destination in self.current_arucos:
            print("You reached your destination!")
            self.destination = None
            self.give_indications = False
        elif type(self.destination) != type(None):
            self.update_Tad()
            print("Tad: " +str(self.Tad))

    def rigid_transform_3D(self, A, B):
        """"Least-Squares Fitting of Two 3-D Point Sets", Arun, K. S. and Huang, T. S. and Blostein, S. D, 
            IEEE Transactions on Pattern Analysis and Machine Intelligence, Volume 9 Issue 5, May 1987"""
        assert A.shape == B.shape

        num_rows, num_cols = A.shape
        if num_rows != 3:
            raise Exception(f"matrix A is not 3xN, it is {num_rows}x{num_cols}")

        num_rows, num_cols = B.shape
        if num_rows != 3:
            raise Exception(f"matrix B is not 3xN, it is {num_rows}x{num_cols}")

        # find mean column wise
        centroid_A = np.mean(A, axis=1)
        centroid_B = np.mean(B, axis=1)

        # ensure centroids are 3x1
        centroid_A = centroid_A.reshape(-1, 1)
        centroid_B = centroid_B.reshape(-1, 1)

        # subtract mean
        Am = A - centroid_A
        Bm = B - centroid_B

        H = Am @ np.transpose(Bm)

        # find rotation
        U, S, Vt = np.linalg.svd(H)
        R = Vt.T @ U.T

        # special reflection case
        if np.linalg.det(R) < 0:
            Vt[2, :] *= -1
            R = Vt.T @ U.T

        #t = -R @ centroid_A + centroid_B
        t = centroid_B - (R @ centroid_A)
        matrix = np.block([[R, t], [0, 0, 0, 1]])

        return matrix,R, t


    def plot_3D_positions(self):

        origin = np.asarray([0,0,0,1])[:,np.newaxis]    
        aruco_positions = self.aruco_positions.copy()

        if len(aruco_positions)>0:
            for k in list(aruco_positions.keys()):
                pos = aruco_positions[k]
                aruco_center = np.asarray([np.mean(pos[0][:]), np.mean(pos[1][:]), np.mean(pos[2][:])])
                self.ax.scatter(aruco_center[0], aruco_center[1], aruco_center[2], color="blue")
                self.ax.text(aruco_center[0], aruco_center[1], aruco_center[2],  '%s' % (k), size=10, zorder=1,color='k')


        
        if type(self.Twc)!=type(None):
            self.curr_position_wc = (self.Twc @ origin)[:3,:]
            self.ax.scatter(self.curr_position_wc[0][0], self.curr_position_wc[1][0], self.curr_position_wc[2][0],color="green")
            self.ax.text(self.curr_position_wc[0][0], self.curr_position_wc[1][0], self.curr_position_wc[2][0],  '%s' % ("cam"), size=10, zorder=1,color='k')
            """
            if len(aruco_positions)>0:
                for k in list(aruco_positions.keys()):
                    pos = aruco_positions[k]
                    aruco_center = np.asarray([np.mean(pos[0][:]), np.mean(pos[1][:]), np.mean(pos[2][:])])
                    self.ax.scatter((aruco_center[0]+self.curr_position_wc[0][0])/2, (aruco_center[1]+self.curr_position_wc[1][0])/2, (aruco_center[2]+self.curr_position_wc[2][0])/2)
                    self.ax.text((aruco_center[0]+self.curr_position_wc[0][0])/2, (aruco_center[1]+self.curr_position_wc[1][0])/2, (aruco_center[2]+self.curr_position_wc[2][0])/2,  '%s' % ("c"+k), size=10, zorder=1,color='k')
            """


        self.ax.scatter(origin[0][0], origin[1][0], origin[2][0],color = "orange")
        self.ax.text(origin[0][0], origin[1][0], origin[2][0],  '%s' % ("ref"), size=10, zorder=1,color='k')

        """
        if type(self.points) != type(None):
            for i in range(13):
                self.ax.scatter(self.points[0][i], self.points[1][i], self.points[2][i])
        """
        
        plt.draw()
        plt.pause(0.02)
        self.ax.cla()

        self.ax.set_xlabel('x')
        self.ax.set_ylabel('y')
        self.ax.set_zlabel('z')

        #self.ax.set_xlim3d(-10,10)
        #self.ax.set_ylim3d(-10,10) 
        #self.ax.set_zlim3d(-10,10) 
        self.ax.set_xlim3d(-2,2)
        self.ax.set_ylim3d(-2,2) 
        self.ax.set_zlim3d(-2,2) 



if __name__=="__main__":
    with open("scripts/navigator_config.json") as jsonFile:
        params = json.load(jsonFile)
    nav = Navigator(params)
    nav.start()
