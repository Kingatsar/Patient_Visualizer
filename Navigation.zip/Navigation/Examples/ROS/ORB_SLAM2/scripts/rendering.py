import cv2
import numpy as np
import math

BLACK = (0, 0, 0)
ORANGE = (0, 140, 255)

def connect_points(image, i, j, points, color=(0,0,0)):
    image = cv2.line(image, (points[i][0], points[i][1]), (points[j][0], points[j][1]), color, 1)
    return image


def render_arrow(image, camera_matrix, transform , Tcw, color = (0, 140, 255),  l1 = 0.2, l2 = 0.5, h1 = 1.5, h2 = 1, d = 0, scale=0.1):
    
    h = image.shape[0]
    w = image.shape[1]
    image_filled = image.copy()
    image2 = np.zeros((h,w),np.uint8)+255
    
    angle = math.pi
    rotation = np.asarray([[math.cos(angle), math.sin(angle), 0, 0], [-math.sin(angle), math.cos(angle), 0, 0],[0,0, 1, 0],[0,0, 0, 1]])

    points = []
    
    
    points.append([-l2/2, -l2/2, d,1])
    points.append([l2/2, -l2/2, d,1])
    points.append([l2/2,  l2/2, d,1])
    points.append([-l2/2, l2/2, d,1])
    points.append([-l1/2, -l1/2, d,1])
    points.append([l1/2, -l1/2, d,1])
    points.append([l1/2,  l1/2, d,1])
    points.append([-l1/2, l1/2, d,1])
    points.append([-l1/2, -l1/2, d-h1,1])
    points.append([l1/2, -l1/2, d-h1,1])
    points.append([l1/2,  l1/2, d-h1,1])
    points.append([-l1/2, l1/2, d-h1,1])
    points.append([0, 0, d+h2,1])
    
    points = []
    points.append([-l2/2, -l2/2, d,1])
    points.append([-l2/2, l2/2, d,1])
    points.append([l2/2,  l2/2, d,1])
    points.append([l2/2, -l2/2, d,1])
    points.append([-l1/2, -l1/2, d,1])
    points.append([-l1/2, l1/2, d,1])
    points.append([l1/2,  l1/2, d,1])
    points.append([l1/2, -l1/2, d,1])
    points.append([-l1/2, -l1/2, d-h1,1])
    points.append([-l1/2, l1/2, d-h1,1])
    points.append([l1/2,  l1/2, d-h1,1])
    points.append([l1/2, -l1/2, d-h1,1])
    points.append([0, 0, d+h2,1])
    """
   
    points = []
    points.append([d, -l2/2, -l2/2,1])
    points.append([d, -l2/2, l2/2,1])
    points.append([d,  l2/2, l2/2,1])
    points.append([d, l2/2, -l2/2,1])
    points.append([d, -l1/2, -l1/2,1])
    points.append([d, -l1/2, l1/2,1])
    points.append([d,  l1/2, l1/2,1])
    points.append([d, l1/2, -l1/2,1])
    points.append([d-h1, -l1/2, -l1/2,1])
    points.append([d-h1, -l1/2, l1/2,1])
    points.append([d-h1,  l1/2, l1/2,1])
    points.append([d-h1, l1/2,-l1/2 ,1])
    points.append([d+h2, 0, 0,1])
    """
    points = np.asarray(points).T

    perspective_projection = np.asarray([[1,0,0,0],[0,1,0,0],[0,0,1,0]])

    center_pos = [w/2, h/2]
    
    """
    points_w = Tw_arrow @ points # 4xn

    projected_points = camera_matrix @ perspective_projection @ Tcw @ points_w

    projected_points = projected_points.T

    print(projected_points.shape)
    print(projected_points)
    projected_points = projected_points[:,:2]
    """
    transform = np.linalg.inv(transform)
    #transform[0][3] = 0
    #transform[1][3] = 0
    #transform[2][3] = 0
    
    points = np.linalg.inv(Tcw) @ points #rotation @ points

    projected_points = camera_matrix @ perspective_projection @ transform @ points

    projected_points = projected_points.T
    print(projected_points)
    print(projected_points.shape)

            
    for i in range(projected_points.shape[0]):
        projected_points[i][0] = int(projected_points[i][0])# + center_pos[0]
        projected_points[i][1] = int(projected_points[i][1])# + center_pos[1]
        if projected_points[i][0] < 0:
            projected_points[i][0] = 0
        if projected_points[i][0] >= w:
            projected_points[i][0] = w

        if projected_points[i][1] < 0:
            projected_points[i][1] = 0
        if projected_points[i][1] >= h:
            projected_points[i][1] = h

    projected_points = projected_points.astype(int)
     


    print("Projected points")
    print(projected_points)

   
    for p in range(4):
        image2 = connect_points(image2, p, (p+1) % 4, projected_points)
        image2 = connect_points(image2, p+4, ((p+1) % 4) + 4, projected_points)
        image2 = connect_points(image2, p+8, ((p+1) % 4) + 8, projected_points)
        image2 = connect_points(image2, p+4, p+8, projected_points)
        image2 = connect_points(image2, p, 12, projected_points)

    cv2.imshow("sds", image2)

    th,im_th = cv2.threshold(image2,200,255,cv2.THRESH_BINARY_INV)
    im_f = im_th.copy()
    mask = np.zeros((h+2,w+2),np.uint8)
    cv2.floodFill(im_f, mask, (0,0), (255,255,255))
   
    b = im_f.copy()
    g = im_f.copy()
    r = im_f.copy()
    b[b==0]=color[0]
    g[g==0]=color[1]
    r[r==0]=color[2]

    image_filled[:,:,0] = b
    image_filled[:,:,1] = g
    image_filled[:,:,2] = r

    frame_overlayed = image.copy()
    frame_overlayed[im_f==0] = image_filled[im_f==0]

    for p in range(4):
        frame_overlayed = connect_points(frame_overlayed, p, (p+1) % 4, projected_points)
        frame_overlayed = connect_points(frame_overlayed, p+4, ((p+1) % 4) + 4, projected_points, ORANGE)
        frame_overlayed = connect_points(frame_overlayed, p+8, ((p+1) % 4) + 8, projected_points)
        frame_overlayed = connect_points(frame_overlayed, p+4, p+8, projected_points)
        frame_overlayed = connect_points(frame_overlayed, p, 12, projected_points)

    return frame_overlayed, points


if __name__ == "__main__":

    camera_matrix = np.matrix([
        [9.7248853929398274e+02, 0, 6.5554573489346024e+02],
        [0, 9.7248853929398274e+02, 3.3608754012074456e+02],
        [0,0,1]
    ])

    camera_matrix = np.matrix([
        [1, 0, 0],
        [0, 1, 0],
        [0,0,1]
    ])

    rotation = np.matrix([[1,0,0],[0,1,0],[0,0,1]])


    cap = cv2.VideoCapture(0)

    ret,img = cap.read()

    img_AR = render_arrow(img, camera_matrix,rotation, scale=100) 

    cv2.imshow("img_AR", img_AR)
    k= cv2.waitKey(0)

    cap.release()