echo "Copying libboost_filesystem.so from x86_64-linux-gnu to lib..."
cp /usr/lib/x86_64-linux-gnu/libboost_filesystem.so ./lib

echo "Copying libboost_system.so from x86_64-linux-gnu to lib..."
cp /usr/lib/x86_64-linux-gnu/libboost_system.so ./lib

echo "Building ROS nodes"

cd Examples/ROS/ORB_SLAM2
mkdir build
cd build
cmake .. -DROS_BUILD_TYPE=Release
make -j
